
newoption {
	trigger     = "akplatform",
	value       = "VALUE",
	description = "Choose one platform to generate",
	allowed = {
		{ "Mac",		"Mac" },
		{ "Linux",	"Linux" },
		{ "iOS", 		"iOS" },
		{ "Windows",  "Windows" },
		{ "Android",  "Android" },
		{ "nacl",		"nacl" },
		{ "Vita",  	"Vita" },
		{ "XboxOne",  "XboxOne" },
		{ "XboxOneADK",  "XboxOneADK" },
		{ "Metro",  "Metro" },
		{ "WinPhone",	"WinPhone" },
		{ "PS4",  "PS4" },
		{ "3DS",  "3DS" },
		{ "QNX",  "QNX" },
		{ "Switch",	"Switch" },
		{ "Lumin",	"Lumin" },
	}
}

function SoundEngineInternals(suffix, communication)
	local d = {
		"AkMusicEngine"..suffix,
		"AkSpatialAudio"..suffix,
		"AkMemoryMgr"..suffix,
		"AkStreamMgr"..suffix,
	}

	if communication then
		d[#d+1] = "CommunicationCentral"..suffix
	end

	d[#d+1] = "AkSoundEngine"..suffix
	d[#d+1] = "AkSilenceSource"..suffix
	d[#d+1] = "AkSineSource"..suffix
	d[#d+1] = "AkToneSource"..suffix
	d[#d+1] = "AkSynthOneSource"..suffix
	d[#d+1] = "AkVorbisDecoder"..suffix
	d[#d+1] = "AkAudioInputSource"..suffix

	return d
end

function Dependencies(suffix, communication)
	local d = SoundEngineInternals(suffix, communication)

	d[#d+1] = "AkCompressorFX"..suffix
	d[#d+1] = "AkDelayFX"..suffix
	d[#d+1] = "AkExpanderFX"..suffix
	d[#d+1] = "AkFlangerFX"..suffix
	d[#d+1] = "AkGainFX"..suffix
	d[#d+1] = "AkGuitarDistortionFX"..suffix
	d[#d+1] = "AkHarmonizerFX"..suffix
	d[#d+1] = "AkMatrixReverbFX"..suffix
	d[#d+1] = "AkMeterFX"..suffix
	d[#d+1] = "AkParametricEQFX"..suffix
	d[#d+1] = "AkPeakLimiterFX"..suffix
	d[#d+1] = "AkPitchShifterFX"..suffix
	d[#d+1] = "AkRecorderFX"..suffix
	d[#d+1] = "AkReflectFX"..suffix
	d[#d+1] = "AkRoomVerbFX"..suffix
	d[#d+1] = "AkStereoDelayFX"..suffix
	d[#d+1] = "AkTimeStretchFX"..suffix
	d[#d+1] = "AkTremoloFX"..suffix	

	return d
end

function CreateCommonProject(platformName, suffix)
	-- A project defines one build target
	local pfFolder = "../"..platformName.."/";
	local prj = project ("AkSoundEngine" .. platformName)
		targetname "AkSoundEngine"
		kind "SharedLib"
		language "C++"
		-- Files must be explicitly specified (no wildcards) because our build system calls premake before copying the sample files
		files {
			"../Common/AkCallbackSerializer.cpp",
			pfFolder .. "AkDefaultIOHookBlocking.cpp",
			"../Common/AkFileLocationBase.cpp",
			"../Common/AkFilePackage.cpp",
			"../Common/AkFilePackageLUT.cpp",
			"../Common/AkSoundEngineStubs.cpp",
			pfFolder .. "SoundEngine_wrap.cxx",
			pfFolder .. "stdafx.cpp",
			}
		defines {
			"AUDIOKINETIC",
			}

		includedirs {
			"../"..platformName,
			"$(WWISESDK)/include",
			"."
			}

		configuration "Debug"
			defines { "_DEBUG" }
			flags { "Symbols" }
			links(Dependencies(suffix, true))

		configuration "Profile"
			defines { "NDEBUG" }
			flags { "Optimize" }
			links(Dependencies(suffix, true))

		configuration "Release"
			defines { "NDEBUG", "AK_OPTIMIZED" }
			flags { "Optimize" }
			links(Dependencies(suffix, false))

		configuration "*"
	return prj
end

function CreateLinuxSln()
	-- A solution contains projects, and defines the available configurations
	solution "AkSoundEngineLinux"
	configurations { "Debug", "Profile", "Release" }
	platforms { "x64", "x32" }

	local prj = CreateCommonProject("Linux", "", false)
		defines "__linux__"
		location "../Linux"
		links "SDL2"

		buildoptions {
			"-fvisibility=hidden",
			"-fdata-sections",
			"-ffunction-sections"
			}

		linkoptions {
			"-Wl,--gc-sections"
		}

		flags {
			"EnableSSE2" 
			}

		local baseTargetDir = "../../Integration/Assets/Wwise/Deployment/Plugins/Linux/"

		configuration { "Debug", "x32" }
			libdirs {
				"$(WWISESDK)/Linux_x32/Debug/lib"
				}
			targetdir( baseTargetDir .. "x86/Debug")

		configuration { "Profile", "x32" }
			libdirs {
				"$(WWISESDK)/Linux_x32/Profile/lib"
				}
			targetdir( baseTargetDir .. "x86/Profile")
			postbuildcommands ("strip " .. baseTargetDir .. "x86/Profile/libAkSoundEngine.so")

		configuration { "Release", "x32" }
			libdirs {
				"$(WWISESDK)/Linux_x32/Release/lib"
				}
			targetdir( baseTargetDir .. "x86/Release")
			postbuildcommands ("strip " .. baseTargetDir .. "x86/Release/libAkSoundEngine.so")

		configuration { "Debug", "x64" }
			libdirs {
				"$(WWISESDK)/Linux_x64/Debug/lib"
				}
			targetdir( baseTargetDir .. "x86_64/Debug")

		configuration { "Profile", "x64" }
			libdirs {
				"$(WWISESDK)/Linux_x64/Profile/lib"
				}
			targetdir( baseTargetDir .. "x86_64/Profile")
			postbuildcommands ( "strip " .. baseTargetDir .. "x86_64/Profile/libAkSoundEngine.so")

		configuration { "Release", "x64" }
			libdirs {
				"$(WWISESDK)/Linux_x64/Release/lib"
				}
			targetdir( baseTargetDir .. "x86_64/Release")
			postbuildcommands ( "strip " .. baseTargetDir .. "x86_64/Release/libAkSoundEngine.so")

		configuration "*x32"
			buildoptions { "-m32", "-msse" }

		configuration "*x64"
			buildoptions { "-m64" }
end

function CreateXboxOneSln()
	-- A solution contains projects, and defines the available configurations
	solution "AkSoundEngineXboxOne"
	location "../XboxOne"
	configurations { "Debug", "Profile", "Release" }
	platforms { "XboxOne" }
	links { "uuid", "acphal", "xaudio2", "combase", "kernelx", "ws2_32", "MMDevApi" }

	local prj = CreateCommonProject("XboxOne", "", false)
		defines { "_XBOX_ONE", "UNICODE", "_UNICODE" }
		location "../XboxOne"
		buildoptions "/Fd$(OutDir)AkSoundEngine.pdb"
		
		local baseTargetDir = "../../Integration/Assets/Wwise/Deployment/Plugins/XboxOne/"
		
		-- Style sheets.
		configuration { "*Debug*" }
			vs_propsheet("../XboxOne/PropertySheets/Debug_vc140.props")
		configuration { "Profile* or *Release*" }
			vs_propsheet("../XboxOne/PropertySheets/NDebug_vc140.props")

		configuration { "Debug", "XboxOne" }
			libdirs {
				"$(WWISESDK)/XboxOne_vc140/Debug/lib"
				}
			local finalTargetDir = baseTargetDir .. "Debug"
			targetdir( finalTargetDir )
			linkoptions ("/WINMDFILE:" .. finalTargetDir .. "/AkSoundEngine.winmd")

		configuration { "Profile", "XboxOne" }
			libdirs {
				"$(WWISESDK)/XboxOne_vc140/Profile/lib"
				}
			local finalTargetDir = baseTargetDir .. "Profile"
			targetdir( finalTargetDir )
			linkoptions ("/WINMDFILE:" .. finalTargetDir .. "/AkSoundEngine.winmd")
	
		configuration { "Release", "XboxOne" }
			libdirs {
				"$(WWISESDK)/XboxOne_vc140/Release/lib"
				}
			local finalTargetDir = baseTargetDir .. "Release"
			targetdir( finalTargetDir )
			linkoptions ("/WINMDFILE:" .. finalTargetDir .. "/AkSoundEngine.winmd")
end

function CreateSwitchSln()
	-- A solution contains projects, and defines the available configurations
	solution "AkSoundEngineSwitch"
	location "../Switch"
	configurations { "Debug", "Profile", "Release" }
	platforms { "NX64" }

		local targetName = "AkSoundEngineWrapper"

	local function ConvertDependenciesToPostBuildStep(dependencies)

		local addLogs = true

		local newLine = "\r\n"
		local saveRootDirectory = "pushd ."
		local returnToRootDirectory = "popd"
		local ar = "$(NINTENDO_SDK_ROOT)/Compilers/NX/nx/aarch64/bin/aarch64-nintendo-nx-elf-ar.exe"

		local output = ""

		if addLogs then
			output = output .. "echo This script is generated within the premake4.lua file." .. newLine
		end

		for i,v in ipairs(dependencies) do

			local tempDirectory = "$(IntDir)" .. v

			local currentLibPath = "$(WWISESDK)/$(Platform)/$(Configuration)/lib/lib" .. v .. ".a"

			local createDirectory = 
				"mkdir " .. tempDirectory .. newLine ..
				"cd " .. tempDirectory

			local extract = ar .. " x \"" .. currentLibPath .. "\""

			local addObjectsToArchive = ar .. " r $(TargetPath) " .. tempDirectory .. "/*.o"

			local removeDirectory = "rmdir /s /q " .. tempDirectory

			if addLogs then
				extract = "echo Extracting objects from library \"" .. currentLibPath .. "\" into temporary directory \"" .. tempDirectory .. "\"." .. newLine .. extract
				addObjectsToArchive = "echo Adding objects to library \"$(TargetFileName)\"." .. newLine .. addObjectsToArchive
			end

			output = output
				.. saveRootDirectory .. newLine
				.. createDirectory .. newLine
				.. extract .. newLine
				.. returnToRootDirectory .. newLine
				.. addObjectsToArchive .. newLine
				.. removeDirectory .. newLine
		end

		return output
	end

	local prj = CreateCommonProject("Switch", ".a")
		targetname(targetName)
		location "../Switch"
		kind "StaticLib"
		flags { "Unicode" }
		uuid "CED61298-E616-2841-B574-03A3EFE03719"
		links {}

		local depends = SoundEngineInternals("", true)
		depends[#depends+1] = "AkOpusDecoder"
		
		local baseTargetDir = "../../Integration/Assets/Wwise/Deployment/Plugins/Switch/"

		-- Standard configuration settings.
		configuration ("*")
			vs_propsheet("../Switch/NintendoSdkSpec_NX.props")
			vs_propsheet("../Switch/NintendoSdkVcProjectSettings.props")

		configuration ("Debug")
			defines ("_DEBUG")
			flags ("Symbols")
			vs_propsheet("../Switch/NintendoSdkBuildType_Debug.props")
			targetdir( baseTargetDir .. "NX64/Debug")
			postbuildcommands(ConvertDependenciesToPostBuildStep(depends))

		configuration ("Profile")
			defines ("NDEBUG")
			flags ({"Symbols", "OptimizeSpeed"})
			vs_propsheet("../Switch/NintendoSdkBuildType_Develop.props")
			targetdir( baseTargetDir .. "NX64/Profile")
			postbuildcommands(ConvertDependenciesToPostBuildStep(depends))

		configuration ("Release")
			defines ({"NDEBUG","AK_OPTIMIZED"})
			flags ({"Symbols", "OptimizeSpeed"})
			vs_propsheet("../Switch/NintendoSdkBuildType_Release.props")
			targetdir( baseTargetDir .. "NX64/Release")
			postbuildcommands(ConvertDependenciesToPostBuildStep(depends))

end

function CreateAndroidSln()
	solution "AkSoundEngineAndroid"
	location "../Android"
	configurations { "Debug", "Profile", "Release" }
	platforms({"android_armeabi_v7a", "android_x86", "android_arm64_v8a", "android_x64"})
	
	local prj = CreateCommonProject("Android", "", false)
		targetname("AkSoundEngine")
		location "../Android"
		kind "SharedLib"

		-- Files must be explicitly specified (no wildcards) because our build system calls premake before copying the sample files
		files
		{
			"../Android/AkFileHelpers.cpp",
		}

		local depends = SoundEngineInternals("", true)			
		local baseTargetDir = "../../Integration/Assets/Wwise/Deployment/Plugins/Android/"

		includedirs
		{
			"$(WWISESDK)/samples/SoundEngine/Android/libzip/lib",
		}

		libdirs
		{
			"$(WWISESDK)/Android_$(ArchAbi)/$(Configuration)/lib/",
		}

		links 
		{
			"OpenSLES",
			"android",
			"log",
			"dl",
			"z",
			"zip",
		}

		targetdir( baseTargetDir .. "$(ArchAbi)/$(Configuration)/")

		-- Standard configuration settings.
		configuration ("*")
			vs_propsheet("../Android/Android.props")

		configuration("Profile")
			linkoptions{"-Wl,--gc-sections -Wl,--icf=all"}

		configuration("Release")
			linkoptions{"-Wl,--gc-sections -Wl,--icf=all"}	
end 

function CreateLuminSln()
	-- A solution contains projects, and defines the available configurations
	solution "AkSoundEngineLumin"
	configurations { "Debug", "Profile", "Release" }
	platforms { "Lumin" }

	local prj = CreateCommonProject("Lumin", "", false)
		defines "AK_LUMIN"
		location "../Lumin"

		links { 
			"log",
			"ml_audio"
		}
		
		flags {
			"NoRTTI", 
			"NoExceptions"
		}

		buildoptions {
			"-fvisibility=hidden",
			"-fdata-sections"
		}

		linkoptions {
			"-Wl,--gc-sections"
		}

		local baseTargetDir = "../../Integration/Assets/Wwise/Deployment/Plugins/Lumin/"
		
		-- careful! $(config) in make does not have proper case, so specify everything directly here:
		configuration { "Debug" }
			libdirs {
				"$(MLSDK)/lib/lumin",
				"$(WWISESDK)/Lumin/Debug/lib"
				}
			targetdir( baseTargetDir .. "/Debug")

		configuration { "Profile" }
			libdirs {
				"$(MLSDK)/lib/lumin",
				"$(WWISESDK)/Lumin/Profile/lib"
				}
			targetdir( baseTargetDir .. "/Profile")

			-- postbuildcommands ("strip " .. baseTargetDir .. "/$(config)/libAkSoundEngine.so")

		configuration { "Release" }
			libdirs {
				"$(MLSDK)/lib/lumin",
				"$(WWISESDK)/Lumin/Release/lib"
				}
			targetdir( baseTargetDir .. "/Release")

			-- postbuildcommands ("strip " .. baseTargetDir .. "/$(config)/libAkSoundEngine.so")
end


if _OPTIONS["akplatform"] == "Linux" then
	CreateLinuxSln();
end
if _OPTIONS["akplatform"] == "Switch" then
	CreateSwitchSln();
end
if _OPTIONS["akplatform"] == "Android" then
	CreateAndroidSln();
end
if _OPTIONS["akplatform"] == "Lumin" then
	CreateLuminSln();
end
if _OPTIONS["akplatform"] == "XboxOne" then
	CreateXboxOneSln();
end
